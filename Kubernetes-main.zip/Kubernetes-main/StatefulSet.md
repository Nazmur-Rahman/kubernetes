## 📘 StatefulSet in Kubernetes

A **StatefulSet** manages stateful applications in Kubernetes. Unlike Deployments, it provides:

* Stable pod identity → Pods get predictable names (app-0, app-1).
* Stable network identity → Each pod gets its own DNS (pod-0.svc).
* Stable storage → Each pod has its own PVC that persists even if the pod restarts.
* Ordered scaling → Pods start/terminate one at a time in order.

**🔹 When to use**
* Databases (MySQL, MongoDB, Cassandra)
* Messaging systems (Kafka, RabbitMQ)
* Any app needing unique identity + storage

***👉 In short:*** Use a `StatefulSet` when your app is not `stateless`.

-------------------------------------------------------------------------------------------

### Task 1: Create StatefulSet
Create the yaml definition for an nginx Stateful Set 
```
vi nginx-sts.yaml
```
Add the given content, by pressing `INSERT`

```yaml
# Headless Service to manage network identity for StatefulSet pods
apiVersion: v1
kind: Service
metadata:
  name: nginx-svc
  labels:
    app: nginx-svc
spec:
  ports:
  - port: 80
    name: web
  clusterIP: None         #Headless service (no ClusterIP)
  selector:
    app: nginx-sts
---
# StatefulSet for Nginx with PVC template
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: nginx-sts
spec:
  serviceName: nginx-svc   #Must match the headless service
  replicas: 2
  selector:
    matchLabels:
      app: nginx-sts
  template:
    metadata:
      labels:
        app: nginx-sts
    spec:
      containers:
      - name: nginx
        image: k8s.gcr.io/nginx-slim:0.8
        ports:
        - containerPort: 80
          name: web
        volumeMounts:
        - name: www
          mountPath: /usr/share/nginx/html
  volumeClaimTemplates:       # PVC template (auto-created per replica)
  - metadata:
      name: www
    spec:
      accessModes: [ "ReadWriteOnce" ]
      resources:
        requests:
          storage: 1Gi
```
save the file using `ESCAPE + :wq!`


Create a Stateful Set and  headless service by applying the yaml
```
kubectl apply -f nginx-sts.yaml
```
Validate the headless service creation
```
kubectl get service nginx-svc
```
Validate the stateful set creation
```
kubectl get statefulset nginx-sts
```
Watch the pods getting created in an ordinal index fashion
```
kubectl get pods -w -l app=nginx-sts
```
Create a busybox pod to test the ping to one of the Ngninx pods by using DNS name of the pod
```
kubectl run -i --tty --image busybox:1.28 dns-test --restart=Never --rm
```
```
nslookup nginx-sts-0.nginx-svc
```
```
nslookup nginx-sts-1.nginx-svc
```
```
exit
```
Delete the pods for a stateful set
```
kubectl delete pod -l app=nginx-sts
```
In another window notice the new pods getting created in a proper order
```
kubectl get pod -w -l app=nginx-sts
```

### Task 2: Scaling a Stateful Set
Scale the Stateful Set to 5 replicas using below.
```
kubectl scale sts nginx-sts --replicas=5
```
Verify the pods getting created in ordinal way
```
kubectl get pods -w -l app=nginx-sts
```
Verify the PV Claim getting created in ordinal fashion
```
kubectl get pvc -l app=nginx-sts
```
Edit the stateful Set yaml and reduce replicas to 3 
```
kubectl edit sts nginx-sts
```
Notice that the controller deletes the pods one at a time. It waits for one to completely shut down before going to next
```
kubectl get pods -w -l app=nginx-sts
```
Verify statefulSet’s PersistentVolumeClaims and verify that are not deleted on scaling down. 
```
kubectl get pvc -l app=nginx-sts
```

### Task 3: Cleanup the resources using below command 
Delete a Stateful Set
```
kubectl delete -f nginx-sts.yaml
```
List all the PV and PVC’s that has been allocated to Statefulset pods and delete them as below.
```
kubectl get pvc
```
```
kubectl delete pvc --all
```



